
🎉 Thank You for Choosing Our Font! 🎉

Dear Valued Customer,

We sincerely appreciate your purchase of our font, Handcaps. Your support means the world to us!

Before you embark on your creative journey with our font, kindly ensure that you are using it in accordance with the license you've purchased. For more details about your specific license terms, please refer to the official https://rahagita.com/license/.

Should you encounter any issues, require assistance, or have any inquiries about the font, please don't hesitate to reach out to our dedicated support team at byrahagita@gmail.com. We are here to help and ensure your experience with our font is nothing short of fantastic.

Once again, thank you for trusting us with your design needs. We can't wait to see the amazing ways you bring Handcaps to life!

Best regards,
Rahagita Studio